import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

export function stableNode(executable, probe = candidate => {
  const result=spawnSync(candidate,['-p','process.versions.node'],{encoding:'utf8',timeout:5000});
  const [major,minor]=result.stdout?.trim().split('.').map(Number)??[];
  return result.status===0&&(major>22||major===22&&minor>=19);
}) {
  // Homebrew's opt link survives upgrades; a Cellar version directory does not.
  const match=executable.match(/^(.*)\/Cellar\/([^/]+)\/[^/]+\/bin\/node$/);
  const candidate=match?`${match[1]}/opt/${match[2]}/bin/node`:executable;
  return candidate!==executable&&probe(candidate)?candidate:executable;
}

export function cacheArchive(archive, install) {
  fs.mkdirSync(install,{recursive:true});
  const destination=path.join(install,'sfls.tgz');
  fs.copyFileSync(archive,destination);
  return destination;
}

export function launcherSource(cli) {
  // Use the interpreter that actually started this launcher, never an installation-time version path.
  return `import {spawnSync} from 'node:child_process';\nimport path from 'node:path';\nconst r=spawnSync(process.execPath,[${JSON.stringify(cli)},...(process.argv.length>2?process.argv.slice(2):['launch'])],{stdio:'inherit',env:{...process.env,PATH:path.dirname(process.execPath)+path.delimiter+(process.env.PATH??'')}});\nif(r.error)console.error(r.error.message);\nprocess.exit(r.status??1);\n`;
}
