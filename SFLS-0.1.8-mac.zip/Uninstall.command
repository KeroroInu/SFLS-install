#!/bin/bash
# Runs without Node, including when the installed interpreter is missing.
set -eu
keep_data=0; preview=0; confirmed=0
for argument in "$@"; do
  case "$argument" in
    --keep-data) keep_data=1 ;;
    --dry-run) preview=1 ;;
    --yes) confirmed=1 ;;
    --help|-h) echo 'sfls uninstall [--keep-data] [--dry-run] [--yes]'; exit 0 ;;
    *) echo "未知卸载选项：$argument" >&2; exit 1 ;;
  esac
done
case "${HOME:-}" in ''|/|.) echo '无法确认个人目录，停止卸载。' >&2; exit 1;; esac
user_dir=$(CDPATH= cd -- "$HOME" && pwd -P)
runtime_dir="$user_dir/.sfls-runtime"
data_dir="$user_dir/.sfls"
if [ -n "${SFLS_HOME:-}" ] && [ "$SFLS_HOME" != "$data_dir" ]; then
  echo '检测到自定义 SFLS_HOME。请先备份并人工核对该目录；未删除任何内容。' >&2; exit 1
fi
for target in "$runtime_dir" "$data_dir"; do
  if [ -L "$target" ] || { [ -e "$target" ] && [ ! -d "$target" ]; }; then
    echo "不是普通 SFLS 目录，停止：$target" >&2; exit 1
  fi
done
for lock in "$data_dir/active.lock" "$runtime_dir/python-install.lock"; do
  if [ -e "$lock" ]; then
    if [ -L "$lock" ] || [ ! -f "$lock" ]; then echo '锁文件异常，停止卸载。' >&2; exit 1; fi
    owner_pid=$(sed -n 's/.*"pid"[[:space:]]*:[[:space:]]*\([0-9][0-9]*\).*/\1/p' "$lock")
    case "$owner_pid" in ''|*[!0-9]*) echo '无法确认运行状态，停止卸载。' >&2; exit 1;; esac
    if kill -0 "$owner_pid" 2>/dev/null; then echo 'SFLS 或环境安装仍在运行，请先退出再卸载。' >&2; exit 1; fi
  fi
done
# Only remove our marked PATH block. Validate all files before making changes.
for profile in .zshrc .bashrc .bash_profile .bash_login .profile; do
  target="$user_dir/$profile"
  if [ -L "$target" ]; then echo "终端配置是链接，请人工处理：$target" >&2; exit 1; fi
  if [ -e "$target" ]; then
    [ -f "$target" ] || { echo '终端配置类型异常。' >&2; exit 1; }
    awk '
      /^# >>> SFLS user command >>>$/ { if (inside || ++starts > 1) exit 1; inside=1; next }
      /^# <<< SFLS user command <<<$/ { if (!inside) exit 1; inside=0; ends++; next }
      END { if (inside || starts != ends) exit 1 }
    ' "$target" || { echo "SFLS 配置标记异常，未修改：$target" >&2; exit 1; }
  fi
done
echo "删除程序、专用 Node/Python 和缓存：$runtime_dir"
if [ "$keep_data" = 0 ]; then echo "删除账户、API 密钥和配置：$data_dir"; else echo "保留账户及密钥（共用电脑请谨慎）：$data_dir"; fi
echo '移除 SFLS 的个人 PATH 配置；不删除任务文件夹、系统 Node/Python 或服务器数据。'
echo '任务内的专用 Python 环境可能依赖被删除的运行环境，重装后可重新准备。'
if [ "$preview" = 1 ]; then echo '仅预览，未修改任何内容。'; exit 0; fi
if [ "$confirmed" = 0 ]; then
  printf '上述删除不可撤销，输入 yes 确认：'
  IFS= read -r answer || exit 1
  if [ "$answer" != yes ]; then echo '已取消。'; exit 0; fi
fi
for profile in .zshrc .bashrc .bash_profile .bash_login .profile; do
  target="$user_dir/$profile"
  if [ -f "$target" ] && grep -q '^# >>> SFLS user command >>>$' "$target"; then
    temporary=$(mktemp "$user_dir/.sfls-uninstall.XXXXXX")
    cp -p "$target" "$temporary"
    awk '/^# >>> SFLS user command >>>$/ {inside=1; next} /^# <<< SFLS user command <<<$/ {inside=0; next} !inside' "$target" > "$temporary"
    mv "$temporary" "$target"
  fi
done
# Exact, fixed product directories only; never follow an override or scan task folders.
if [ "$keep_data" = 0 ]; then /bin/rm -rf -- "$data_dir"; fi
/bin/rm -rf -- "$runtime_dir"
echo 'SFLS 已卸载。任务作品和原终端配置备份保留；请重新打开终端。'
