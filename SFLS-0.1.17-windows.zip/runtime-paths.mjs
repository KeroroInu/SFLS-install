import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

export function stableNode(executable, probe = candidate => {
  const result=spawnSync(candidate,['-p','process.versions.node'],{encoding:'utf8',timeout:5000});
  const [major,minor]=result.stdout?.trim().split('.').map(Number)??[];
  return result.status===0&&(major>22||major===22&&minor>=19);
}) {
  // Homebrew's opt link survives upgrades; a Cellar version directory does not.
  const match=executable.match(/^(.*)\/Cellar\/([^/]+)\/[^/]+\/bin\/node$/);
  const candidate=match?`${match[1]}/opt/${match[2]}/bin/node`:executable;
  return candidate!==executable&&probe(candidate)?candidate:executable;
}

export function cacheArchive(archive, install) {
  fs.mkdirSync(install,{recursive:true});
  // npm otherwise walks upwards to a parent's package.json OR node_modules directory.
  if(!fs.existsSync(path.join(install,'package.json')))fs.writeFileSync(path.join(install,'package.json'),JSON.stringify({name:'sfls-local-runtime',version:'0.0.0',private:true}));
  const destination=path.join(install,'sfls.tgz');
  fs.copyFileSync(archive,destination);
  return destination;
}

export function installArguments(install) {
  return ['install','--prefix',fs.realpathSync(install),'--ignore-scripts','--omit=dev','--no-audit','--no-fund','--registry=https://registry.npmjs.org','./sfls.tgz'];
}

// Recover only the active, previously installed offline runtime. Do not evaluate an
// old launcher, trust inherited environment variables, or guess among old versions.
export function installedOfflineRuntime(root,platform=process.platform,arch=process.arch) {
  const pointer=path.join(root,'node-path.txt');
  const fail=()=>{throw new Error('已安装的离线环境不完整或与本机不匹配，未替换启动入口；请重新运行老师的离线安装包。');};
  try {
    let rootStat,pointerStat;
    try {rootStat=fs.lstatSync(root);}catch(error){if(error.code==='ENOENT')return;throw error;}
    if(rootStat.isSymbolicLink()||!rootStat.isDirectory())fail();
    try {pointerStat=fs.lstatSync(pointer);}catch(error){if(error.code==='ENOENT')return;throw error;}
    if(pointerStat.isSymbolicLink()||!pointerStat.isFile()||pointerStat.size>4096)fail();
    const current=fs.readFileSync(pointer,'utf8').trim();
    if(!path.isAbsolute(current))return;
    const relative=path.relative(root,current),parts=relative.split(path.sep);
    if(relative.startsWith('..'+path.sep)||path.isAbsolute(relative)||!parts[0].startsWith('offline-'))return;
    const runtime=path.join(root,parts[0]),realRoot=fs.realpathSync(root);
    const within=(base,file)=>{const r=path.relative(base,file);return r!==''&&!r.startsWith('..'+path.sep)&&r!=='..'&&!path.isAbsolute(r);};
    if(fs.lstatSync(runtime).isSymbolicLink()||!within(realRoot,fs.realpathSync(runtime)))fail();
    const realRuntime=fs.realpathSync(runtime);
    const file=(name,allowLink=false,base=realRuntime)=>{
      const target=path.join(runtime,name),stat=fs.lstatSync(target);
      if(!allowLink&&stat.isSymbolicLink()||!within(base,fs.realpathSync(target))||!fs.statSync(target).isFile()||fs.statSync(target).size===0)fail();
      return target;
    };
    const metadata=file('offline-ready.json');
    if(fs.statSync(metadata).size>65536)fail();
    const meta=JSON.parse(fs.readFileSync(metadata,'utf8'));
    if(!/^\d+\.\d+\.\d+$/.test(meta.version)||meta.target!==`${platform}-${arch}`||parts[0]!==`offline-${meta.version}-${meta.target}`||!/^[a-f0-9]{64}$/.test(meta.appSha))fail();
    const node=file(platform==='win32'?'node/node.exe':'node/bin/node');
    if(path.resolve(current)!==node||!/^\d+\.\d+\.\d+$/.test(meta.python))fail();
    const pythonRoot=fs.realpathSync(path.join(runtime,'python'));
    if(fs.lstatSync(path.join(runtime,'python')).isSymbolicLink()||!within(realRuntime,pythonRoot))fail();
    const python=file(platform==='win32'?'python/python.exe':'python/bin/python3',platform!=='win32',pythonRoot);
    const lib=platform==='win32'?'python/Lib':`python/lib/python${meta.python.split('.').slice(0,2).join('.')}`;
    file(`${lib}/venv/__init__.py`);file(`${lib}/ensurepip/__init__.py`);
    const bundled=path.join(runtime,lib,'ensurepip/_bundled');
    if(!fs.readdirSync(bundled).some(name=>/^pip-[\d.]+-py3-none-any\.whl$/.test(name)&&file(`${lib}/ensurepip/_bundled/${name}`)))fail();
    const wheels=path.join(runtime,'wheels');
    if(fs.lstatSync(wheels).isSymbolicLink()||!fs.statSync(wheels).isDirectory()||!within(realRuntime,fs.realpathSync(wheels)))fail();
    if(!Array.isArray(meta.packages)||meta.packages.length>20||meta.packages.some(p=>typeof p!=='string'||!/^[A-Za-z0-9][A-Za-z0-9._-]*==[0-9]+(?:\.[0-9]+)*(?:(?:a|b|rc)[0-9]+)?$/.test(p)))fail();
    const available=fs.readdirSync(wheels);
    for(const specification of meta.packages) {
      const [name,version]=specification.split('=='),prefix=`${name.replace(/[-.]/g,'_')}-${version}-`.toLowerCase();
      if(!available.some(name=>name.toLowerCase().startsWith(prefix)&&name.endsWith('.whl')&&file(`wheels/${name}`)))fail();
    }
    return {python,wheels};
  } catch {fail();}
}

export function launcherSource(cli,offline) {
  // Use the interpreter that actually started this launcher, never an installation-time version path.
  return `import {spawnSync} from 'node:child_process';\nimport path from 'node:path';\nconst env={...process.env,PATH:path.dirname(process.execPath)+path.delimiter+(process.env.PATH??'')};\ndelete env.SFLS_OFFLINE_PYTHON;delete env.SFLS_OFFLINE_WHEELS;\n${offline?`env.SFLS_OFFLINE_PYTHON=${JSON.stringify(offline.python)};env.SFLS_OFFLINE_WHEELS=${JSON.stringify(offline.wheels)};env.PATH=path.dirname(env.SFLS_OFFLINE_PYTHON)+path.delimiter+env.PATH;\n`:''}const r=spawnSync(process.execPath,[${JSON.stringify(cli)},...(process.argv.length>2?process.argv.slice(2):['launch'])],{stdio:'inherit',env});\nif(r.error)console.error(r.error.message);\nprocess.exit(r.status??1);\n`;
}
