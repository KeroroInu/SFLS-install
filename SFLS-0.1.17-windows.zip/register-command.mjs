import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';

const start='# >>> SFLS user command >>>';
const end='# <<< SFLS user command <<<';
const block=`${start}\ncase ":$PATH:" in\n  *":$HOME/.sfls-runtime/bin:"*) ;;\n  *) export PATH="$HOME/.sfls-runtime/bin:$PATH" ;;\nesac\n${end}`;
export function profileText(previous) {
  const starts=previous.split(start).length-1,ends=previous.split(end).length-1;
  if(starts!==ends||starts>1)throw new Error('SFLS 环境配置标记不完整，请老师检查；没有覆盖配置。');
  if(starts===1) {
    const from=previous.indexOf(start),to=previous.indexOf(end);
    if(to<from)throw new Error('SFLS 环境配置顺序无效');
    return previous.slice(0,from)+block+previous.slice(to+end.length);
  }
  return previous+(previous&&!previous.endsWith('\n')?'\n':'')+'\n'+block+'\n';
}
export function registerMacCommand(root,home,shell) {
  const kind=path.basename(shell);
  if(!['zsh','bash'].includes(kind))throw new Error('当前 shell 不在自动配置范围内，请老师将 .sfls-runtime/bin 加入个人 PATH');
  const loginProfile=['.bash_profile','.bash_login','.profile'].find(name=>fs.existsSync(path.join(home,name)))??'.bash_profile';
  const profiles=(kind==='zsh'?['.zshrc']:['.bashrc',loginProfile]).map(name=>path.join(home,name));
  // Validate everything before writing any profile. Do not follow a profile symlink.
  const changes=profiles.map(file=>{
    let stat;try {stat=fs.lstatSync(file);}catch(error){if(error.code!=='ENOENT')throw error;}
    if(stat&&!stat.isFile())throw new Error('终端配置是链接或特殊文件，未自动修改，请老师处理');
    const previous=fs.existsSync(file)?fs.readFileSync(file,'utf8'):'';
    return {file,previous,next:profileText(previous)};
  });
  fs.mkdirSync(path.join(root,'bin'),{recursive:true});
  fs.writeFileSync(path.join(root,'bin/sfls'),`#!/bin/sh
SFLS_RUNTIME=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd) || exit 1
if [ "\${1:-}" = uninstall ]; then
  shift
  exec /bin/bash "$SFLS_RUNTIME/Uninstall.command" "$@"
fi
SFLS_NODE=''
if [ -f "$SFLS_RUNTIME/node-path.txt" ]; then IFS= read -r SFLS_NODE < "$SFLS_RUNTIME/node-path.txt"; fi
for candidate in "$SFLS_NODE" "$(command -v node 2>/dev/null)" /opt/homebrew/opt/node@22/bin/node /opt/homebrew/bin/node /usr/local/opt/node@22/bin/node /usr/local/bin/node "$SFLS_RUNTIME"/node-v*-darwin-*/bin/node; do
  [ -x "$candidate" ] || continue
  "$candidate" -e 'const [a,b]=process.versions.node.split(".").map(Number);process.exit(a>22||a===22&&b>=19?0:1)' >/dev/null 2>&1 || continue
  exec "$candidate" "$SFLS_RUNTIME/launch.mjs" "$@"
done
echo '没有找到 Node 22.19+，请重新运行 SFLS 安装包；作品不会被覆盖。' >&2
exit 1
`,{mode:0o755});
  fs.chmodSync(path.join(root,'bin/sfls'),0o755);
  const backups=[];
  for(const {file,previous,next} of changes) {
    if(next===previous)continue;
    if(fs.existsSync(file)) {const backup=`${file}.sfls-backup-${randomUUID()}`;fs.copyFileSync(file,backup);backups.push(backup);}
    const temp=`${file}.sfls-${randomUUID()}.tmp`;
    fs.writeFileSync(temp,next,{mode:fs.existsSync(file)?fs.statSync(file).mode&0o777:0o600});
    fs.renameSync(temp,file);
  }
  return backups;
}
export function writeWindowsCommand(root) {
  fs.mkdirSync(path.join(root,'bin'),{recursive:true});
  // Like task Start.cmd, ordinary launches call the installed Node directly.
  // PowerShell policy is still respected for the existing uninstall dispatcher.
  // Read the UTF-8 pointer with delayed expansion disabled, strip quotes (not
  // legal in Windows filenames), and never CALL/re-expand its contents.
  fs.writeFileSync(path.join(root,'bin/sfls.cmd'),[
    '@echo off','setlocal DisableDelayedExpansion',
    'chcp 65001 >nul',
    'if /i "%~1"=="uninstall" goto uninstall',
    'set "SFLS_NODE="',
    'if not exist "%~dp0..\\node-path.txt" goto missing',
    'if not exist "%~dp0..\\launch.mjs" goto missing',
    'set /p "SFLS_NODE="<"%~dp0..\\node-path.txt"',
    'set "SFLS_NODE=%SFLS_NODE:"=%"',
    'if not defined SFLS_NODE goto missing',
    'if not exist "%SFLS_NODE%" goto missing',
    '"%SFLS_NODE%" -e "const [a,b]=process.versions.node.split(\'.\').map(Number);process.exit(a>22||a===22&&b>=19?0:1)" >nul 2>&1',
    'if errorlevel 1 goto missing',
    '"%SFLS_NODE%" "%~dp0..\\launch.mjs" %*',
    'exit /b %errorlevel%',
    ':uninstall',
    'powershell.exe -NoProfile -File "%~dp0..\\run.ps1" %*',
    'exit /b %errorlevel%',
    ':missing',
    'echo SFLS runtime is missing or needs Node 22.19+. Ask your teacher to reinstall. Your task files were not changed. 1>&2',
    'exit /b 1','',
  ].join('\r\n'));
}
