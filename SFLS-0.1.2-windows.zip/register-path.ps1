param([Parameter(Mandatory=$true)][string]$BinPath)
$ErrorActionPreference = 'Stop'
$previous = [Environment]::GetEnvironmentVariable('Path', 'User')
$parts = @($previous -split ';' | Where-Object { $_ })
if ($parts -notcontains $BinPath) {
    # Save the original user setting before changing it. Machine PATH is untouched.
    $backup = Join-Path (Split-Path $BinPath) ('user-path-backup-' + [guid]::NewGuid() + '.txt')
    [IO.File]::WriteAllText($backup, [string]$previous)
    [Environment]::SetEnvironmentVariable('Path', (($BinPath) + ';' + $previous), 'User')
    Write-Host "User PATH backup: $backup"
}
Write-Host 'Open a new terminal window to use sfls. Machine PATH and execution policy were not changed.'
