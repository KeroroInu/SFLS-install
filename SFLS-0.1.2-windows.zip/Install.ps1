$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$sflsRuntime = Join-Path ([Environment]::GetFolderPath('UserProfile')) '.sfls-runtime'
$sflsNodeCommand = Get-Command node.exe -ErrorAction SilentlyContinue
$sflsNpmCommand = Get-Command npm.cmd -ErrorAction SilentlyContinue
$sflsNode = if ($sflsNodeCommand) { $sflsNodeCommand.Source } else { $null }
$sflsNpm = if ($sflsNpmCommand) { Join-Path (Split-Path $sflsNpmCommand.Source) 'node_modules\npm\bin\npm-cli.js' } else { $null }
$sflsValid = $false
if ($sflsNode -and $sflsNpm -and (Test-Path -LiteralPath $sflsNpm)) {
    $sflsVersionText = & $sflsNode --version
    if ($LASTEXITCODE -eq 0) {
        try { $sflsValid = ([version]$sflsVersionText.TrimStart('v')) -ge ([version]'22.19.0') } catch { $sflsValid = $false }
    }
}
if (-not $sflsValid) {
    $sflsCpu = [Environment]::GetEnvironmentVariable('PROCESSOR_ARCHITEW6432')
    if (-not $sflsCpu) { $sflsCpu = [Environment]::GetEnvironmentVariable('PROCESSOR_ARCHITECTURE') }
    switch ($sflsCpu) {
        'ARM64' { $sflsArch = 'arm64'; $sflsHash = '5b44fd410df7b4cd0a1891a05a7b606f8fb7d8786a94997b996a372e82478d7a' }
        'AMD64' { $sflsArch = 'x64'; $sflsHash = 'c97fa376d2becdc8863fcd3ca2dd9a83a9f3468ee7ccf7a6d076ec66a645c77a' }
        default { throw 'Unsupported CPU. Ask your teacher. 32-bit Windows is not supported.' }
    }
    $sflsFolder = "node-v22.22.0-win-$sflsArch"
    $sflsNode = Join-Path $sflsRuntime "$sflsFolder\node.exe"
    if (-not (Test-Path -LiteralPath $sflsNode)) {
        $sflsAnswer = Read-Host 'Download Node.js 22.22.0 from nodejs.org into your SFLS folder? [y/N]'
        if ($sflsAnswer -ne 'y') { throw 'Cancelled.' }
        $sflsTemp = Join-Path $sflsRuntime ('node-download-' + [guid]::NewGuid())
        New-Item -ItemType Directory -Path $sflsTemp -Force | Out-Null
        $sflsArchive = Join-Path $sflsTemp 'node.zip'
        Invoke-WebRequest -UseBasicParsing -Uri "https://nodejs.org/dist/v22.22.0/$sflsFolder.zip" -OutFile $sflsArchive -TimeoutSec 300
        if ((Get-FileHash -LiteralPath $sflsArchive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $sflsHash) { throw 'Checksum failed. Nothing executed.' }
        Expand-Archive -LiteralPath $sflsArchive -DestinationPath $sflsTemp
        $sflsDestination = Join-Path $sflsRuntime $sflsFolder
        if (Test-Path -LiteralPath $sflsDestination) { throw 'Existing runtime needs teacher inspection; not overwriting.' }
        Move-Item -LiteralPath (Join-Path $sflsTemp $sflsFolder) -Destination $sflsDestination
    }
    $sflsNpm = Join-Path $sflsRuntime "$sflsFolder\node_modules\npm\bin\npm-cli.js"
}
& $sflsNode (Join-Path $PSScriptRoot 'install.mjs') $sflsNpm
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
