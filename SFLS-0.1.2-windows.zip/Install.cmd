@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell.exe -NoProfile -File "%~dp0Install.ps1"
if errorlevel 1 echo Setup stopped. Ask your teacher to check network, permissions or approved script policy. Do not disable school security settings.
pause
