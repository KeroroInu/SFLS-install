import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';

const start='# >>> SFLS user command >>>';
const end='# <<< SFLS user command <<<';
const block=`${start}\ncase ":$PATH:" in\n  *":$HOME/.sfls-runtime/bin:"*) ;;\n  *) export PATH="$HOME/.sfls-runtime/bin:$PATH" ;;\nesac\n${end}`;
export function profileText(previous) {
  const starts=previous.split(start).length-1,ends=previous.split(end).length-1;
  if(starts!==ends||starts>1)throw new Error('SFLS 环境配置标记不完整，请老师检查；没有覆盖配置。');
  if(starts===1) {
    const from=previous.indexOf(start),to=previous.indexOf(end);
    if(to<from)throw new Error('SFLS 环境配置顺序无效');
    return previous.slice(0,from)+block+previous.slice(to+end.length);
  }
  return previous+(previous&&!previous.endsWith('\n')?'\n':'')+'\n'+block+'\n';
}
export function registerMacCommand(root,home,shell) {
  const kind=path.basename(shell);
  if(!['zsh','bash'].includes(kind))throw new Error('当前 shell 不在自动配置范围内，请老师将 .sfls-runtime/bin 加入个人 PATH');
  const loginProfile=['.bash_profile','.bash_login','.profile'].find(name=>fs.existsSync(path.join(home,name)))??'.bash_profile';
  const profiles=(kind==='zsh'?['.zshrc']:['.bashrc',loginProfile]).map(name=>path.join(home,name));
  // Validate everything before writing any profile. Do not follow a profile symlink.
  const changes=profiles.map(file=>{
    let stat;try {stat=fs.lstatSync(file);}catch(error){if(error.code!=='ENOENT')throw error;}
    if(stat&&!stat.isFile())throw new Error('终端配置是链接或特殊文件，未自动修改，请老师处理');
    const previous=fs.existsSync(file)?fs.readFileSync(file,'utf8'):'';
    return {file,previous,next:profileText(previous)};
  });
  fs.mkdirSync(path.join(root,'bin'),{recursive:true});
  fs.writeFileSync(path.join(root,'bin/sfls'),`#!/bin/sh\nSFLS_RUNTIME=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd) || exit 1\nIFS= read -r SFLS_NODE < "$SFLS_RUNTIME/node-path.txt" || exit 1\nexec "$SFLS_NODE" "$SFLS_RUNTIME/launch.mjs" "$@"\n`,{mode:0o755});
  fs.chmodSync(path.join(root,'bin/sfls'),0o755);
  const backups=[];
  for(const {file,previous,next} of changes) {
    if(next===previous)continue;
    if(fs.existsSync(file)) {const backup=`${file}.sfls-backup-${randomUUID()}`;fs.copyFileSync(file,backup);backups.push(backup);}
    const temp=`${file}.sfls-${randomUUID()}.tmp`;
    fs.writeFileSync(temp,next,{mode:fs.existsSync(file)?fs.statSync(file).mode&0o777:0o600});
    fs.renameSync(temp,file);
  }
  return backups;
}
export function writeWindowsCommand(root) {
  fs.mkdirSync(path.join(root,'bin'),{recursive:true});
  fs.writeFileSync(path.join(root,'bin/sfls.cmd'),[
    '@echo off','setlocal DisableDelayedExpansion',
    'set /p SFLS_NODE=<"%~dp0..\\node-path.txt"',
    '"%SFLS_NODE%" "%~dp0..\\launch.mjs" %*',
    'exit /b %errorlevel%','',
  ].join('\r\n'));
}
