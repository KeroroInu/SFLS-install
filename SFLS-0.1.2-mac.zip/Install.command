#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
trap 'code=$?; if [ "$code" -ne 0 ]; then echo "Setup stopped. Check network / permissions. Do not disable school security settings."; fi; read -r -p "Press Enter to close... " answer || true' EXIT
if [ "$(uname -s)" != Darwin ]; then echo 'This installer is for macOS.'; exit 1; fi
SFLS_RUNTIME="$HOME/.sfls-runtime"
SFLS_NODE="$(command -v node || true)"
SFLS_NPM="$(command -v npm || true)"
if [ -z "$SFLS_NODE" ] || [ -z "$SFLS_NPM" ] || ! "$SFLS_NODE" -e 'const [a,b]=process.versions.node.split(".").map(Number);process.exit(a>22||a===22&&b>=19?0:1)' 2>/dev/null; then
  case "$(uname -m)" in
    arm64) SFLS_ARCH=arm64; SFLS_SHA=5ed4db0fcf1eaf84d91ad12462631d73bf4576c1377e192d222e48026a902640 ;;
    x86_64) SFLS_ARCH=x64; SFLS_SHA=5ea50c9d6dea3dfa3abb66b2656f7a4e1c8cef23432b558d45fb538c7b5dedce ;;
    *) echo 'Unsupported CPU. Ask your teacher.'; exit 1 ;;
  esac
  SFLS_FOLDER="node-v22.22.0-darwin-$SFLS_ARCH"
  SFLS_NODE="$SFLS_RUNTIME/$SFLS_FOLDER/bin/node"
  if [ ! -x "$SFLS_NODE" ]; then
    read -r -p 'Download Node.js 22.22.0 from nodejs.org into your SFLS folder? [y/N] ' answer
    case "$answer" in y|Y) ;; *) echo 'Cancelled.'; exit 1 ;; esac
    mkdir -p "$SFLS_RUNTIME"
    SFLS_TEMP="$(mktemp -d "$SFLS_RUNTIME/node-download.XXXXXX")"
    /usr/bin/curl --proto '=https' --tlsv1.2 --fail --location --retry 2 --connect-timeout 20 --max-time 300 "https://nodejs.org/dist/v22.22.0/$SFLS_FOLDER.tar.gz" -o "$SFLS_TEMP/node.tar.gz"
    SFLS_ACTUAL="$(/usr/bin/shasum -a 256 "$SFLS_TEMP/node.tar.gz")"
    if [ "${SFLS_ACTUAL%% *}" != "$SFLS_SHA" ]; then echo 'Checksum failed. Nothing executed.'; exit 1; fi
    /usr/bin/tar -xzf "$SFLS_TEMP/node.tar.gz" -C "$SFLS_TEMP"
    if [ -e "$SFLS_RUNTIME/$SFLS_FOLDER" ]; then echo 'Existing runtime needs teacher inspection; not overwriting.'; exit 1; fi
    mv "$SFLS_TEMP/$SFLS_FOLDER" "$SFLS_RUNTIME/$SFLS_FOLDER"
  fi
  SFLS_NPM="$SFLS_RUNTIME/$SFLS_FOLDER/lib/node_modules/npm/bin/npm-cli.js"
fi
"$SFLS_NODE" install.mjs "$SFLS_NPM"
