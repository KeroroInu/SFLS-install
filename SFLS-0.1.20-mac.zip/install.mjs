import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { createInterface } from 'node:readline/promises';
import { registerMacCommand, writeWindowsCommand } from './register-command.mjs';
import { stableNode, cacheArchive, launcherSource, installArguments, installedOfflineRuntime } from './runtime-paths.mjs';

const source=path.dirname(fileURLToPath(import.meta.url));
const root=path.join(os.homedir(),'.sfls-runtime');
const offline=installedOfflineRuntime(root);
const metadata=JSON.parse(fs.readFileSync(path.join(source,'package-manifest.json'),'utf8'));
const tgz=path.join(source,'sfls.tgz');
const digest=createHash('sha256').update(fs.readFileSync(tgz)).digest('hex');
if(digest!==metadata.sha256)throw new Error('SFLS 安装包校验失败，请重新下载老师提供的安装包。');
const npmCli=fs.realpathSync(process.argv[2]);
const install=path.join(root,`app-${digest.slice(0,16)}`);
const cli=path.join(install,'node_modules','@keroroinu','sfls','bin','sfls.mjs');
const rl=createInterface({input:process.stdin,output:process.stdout});
try {
  console.log('SFLS 安装器：软件写入个人 .sfls-runtime 目录，不需要管理员权限。安装后可选择注册个人终端命令。');
  if(!fs.existsSync(path.join(install,'installed.json'))) {
    const answer=await rl.question('允许从 npm 官方源下载 SFLS 的固定依赖吗？[y/N]：');
    if(answer.trim().toLowerCase()!=='y')throw new Error('已取消安装');
    cacheArchive(tgz,install);
    console.log('正在安装 SFLS，请稍候……');
    const result=spawnSync(process.execPath,[npmCli,...installArguments(install)],{cwd:install,stdio:'inherit',timeout:600000,env:{...process.env,PATH:path.dirname(process.execPath)+path.delimiter+(process.env.PATH??'')}});
    if(result.error||result.status!==0)throw new Error('依赖下载未完成。检查 npm 网络访问和磁盘权限后，再次运行此安装器。');
    const verify=spawnSync(process.execPath,[cli,'--version'],{encoding:'utf8',timeout:15000});
    if(verify.status!==0||verify.stdout.trim()!==metadata.version)throw new Error('SFLS 安装后自检未通过，请老师检查；旧版本入口没有更改。');
    fs.writeFileSync(path.join(install,'installed.json'),JSON.stringify({sha256:digest,version:metadata.version}));
  }
  fs.mkdirSync(root,{recursive:true});
  fs.writeFileSync(path.join(root,'launch.mjs'),launcherSource(cli,offline));
  // Store the executable separately for task launchers: no global shell profile edits.
  // Keep the validated offline Node pointer so later updates can recover it again.
  if(!offline)fs.writeFileSync(path.join(root,'node-path.txt'),stableNode(process.execPath)+'\n');
  if(offline)console.log('已保留老师安装包中的离线 Python 和课程依赖，不会改用学校的系统 Python。');
  for(const file of process.platform==='win32'?['Uninstall.ps1','run.ps1']:['Uninstall.command'])fs.copyFileSync(path.join(source,file),path.join(root,file));
  const commandAnswer=await rl.question('允许注册 sfls 终端命令吗？仅更新个人 shell/PATH，保留原配置备份，不修改机器级设置。[y/N]：');
  if(commandAnswer.trim().toLowerCase()==='y') {
    if(process.platform==='darwin') {
      if(process.env.ZDOTDIR&&path.resolve(process.env.ZDOTDIR)!==os.homedir())throw new Error('SFLS 已安装；检测到自定义 ZDOTDIR，请老师把个人 .sfls-runtime/bin 加入该终端配置，未改写其他目录。');
      const backups=registerMacCommand(root,os.homedir(),process.env.SHELL??'/bin/zsh');
      for(const file of backups)console.log(`已备份终端配置：${file}`);
    } else if(process.platform==='win32') {
      writeWindowsCommand(root);
      const result=spawnSync('powershell.exe',['-NoProfile','-File',path.join(source,'register-path.ps1'),'-BinPath',path.join(root,'bin')],{stdio:'inherit',timeout:30000});
      if(result.status!==0)throw new Error('SFLS 已安装，但个人命令注册受限。仍可用任务包 Start；请老师检查脚本策略，不要关闭安全防护。');
    }
    console.log('请重新打开终端，在任务文件夹输入 sfls。已有终端的 PATH 不会被后台修改。');
  }
  console.log('SFLS 已安装。登录学生平台下载本人的新版任务包，解压后双击 Start 或在任务文件夹输入 sfls；不再重复输入学号密码。首次按提示配置 API key，缺少的课程环境会提示准备。');
  console.log('已有任务包若仍提示未安装，请从平台重新下载。模型和 API 额度尚未联网验证。');
  console.log('卸载：sfls uninstall；保留账户配置：sfls uninstall --keep-data。任务作品不会被扫描删除。');
} finally {rl.close();}
