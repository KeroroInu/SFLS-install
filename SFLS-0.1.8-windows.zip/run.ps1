﻿$ErrorActionPreference = 'Stop'
$runtimeDir = $PSScriptRoot
if ($args.Count -gt 0 -and $args[0] -eq 'uninstall') {
    $rest = @($args | Select-Object -Skip 1)
    # No managed Node process is running when its directory is removed.
    & (Join-Path $runtimeDir 'Uninstall.ps1') @rest
    exit $LASTEXITCODE
}
$candidates = @()
$nodeFile = Join-Path $runtimeDir 'node-path.txt'
if (Test-Path -LiteralPath $nodeFile) { $candidates += (Get-Content -LiteralPath $nodeFile -Raw).Trim() }
$available = Get-Command node.exe -ErrorAction SilentlyContinue
if ($available) { $candidates += $available.Source }
$candidates += @(Get-ChildItem -LiteralPath $runtimeDir -Directory -Filter 'node-v*-win-*' | ForEach-Object { Join-Path $_.FullName 'node.exe' })
foreach ($candidate in ($candidates | Select-Object -Unique)) {
    if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) { continue }
    try { $version = & $candidate -p 'process.versions.node' 2>$null } catch { continue }
    if ($LASTEXITCODE -ne 0 -or $version -notmatch '^\d+\.\d+\.\d+$' -or [version]$version -lt [version]'22.19.0') { continue }
    & $candidate (Join-Path $runtimeDir 'launch.mjs') @args
    exit $LASTEXITCODE
}
throw '没有找到 Node 22.19+，请重新运行 SFLS 安装包；作品不会被覆盖。'
