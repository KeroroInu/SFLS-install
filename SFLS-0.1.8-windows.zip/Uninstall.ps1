﻿$ErrorActionPreference = 'Stop'
$keepData = $false; $preview = $false; $confirmed = $false
foreach ($argument in $args) {
    switch ($argument) {
        '--keep-data' { $keepData = $true }
        '--dry-run' { $preview = $true }
        '--yes' { $confirmed = $true }
        '--help' { Write-Host 'sfls uninstall [--keep-data] [--dry-run] [--yes]'; exit 0 }
        default { throw "未知卸载选项：$argument" }
    }
}
$userDir = [Environment]::GetFolderPath('UserProfile')
if (-not $userDir -or $userDir -eq [IO.Path]::GetPathRoot($userDir)) { throw '无法确认个人目录。' }
$runtimeDir = Join-Path $userDir '.sfls-runtime'
$dataDir = Join-Path $userDir '.sfls'
if ($env:SFLS_HOME -and [IO.Path]::GetFullPath($env:SFLS_HOME) -ne $dataDir) { throw '检测到自定义 SFLS_HOME，请人工核对；未删除任何内容。' }
foreach ($target in @($runtimeDir, $dataDir)) {
    if (Test-Path -LiteralPath $target) {
        $item = Get-Item -LiteralPath $target -Force
        if (-not $item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw "不是普通 SFLS 目录：$target" }
        # Refuse nested junctions too: Windows PowerShell versions differ in recursive removal behavior.
        $pending = New-Object 'System.Collections.Generic.Stack[string]'
        $pending.Push($target)
        while ($pending.Count -gt 0) {
            foreach ($child in Get-ChildItem -LiteralPath $pending.Pop() -Force) {
                if ($child.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "目录中有链接，请人工处理：$($child.FullName)" }
                if ($child.PSIsContainer) { $pending.Push($child.FullName) }
            }
        }
    }
}
foreach ($lock in @((Join-Path $dataDir 'active.lock'), (Join-Path $runtimeDir 'python-install.lock'))) {
    if (Test-Path -LiteralPath $lock) {
        $ownerId = (Get-Content -LiteralPath $lock -Raw | ConvertFrom-Json).pid
        if (-not $ownerId -or $ownerId -notmatch '^\d+$') { throw '无法确认运行状态。' }
        if (Get-Process -Id $ownerId -ErrorAction SilentlyContinue) { throw 'SFLS 或环境安装仍在运行，请先退出再卸载。' }
    }
}
Write-Host "删除程序、专用 Node/Python 和缓存：$runtimeDir"
if ($keepData) { Write-Host "保留账户及密钥（共用电脑请谨慎）：$dataDir" } else { Write-Host "删除账户、API 密钥和配置：$dataDir" }
Write-Host '移除个人 PATH 中的 SFLS 入口；任务文件夹、系统环境、服务器数据不会删除。'
Write-Host '任务内的 Python 环境可能需要在重装后重新准备。'
if ($preview) { Write-Host '仅预览，未修改任何内容。'; exit 0 }
if (-not $confirmed -and (Read-Host '上述删除不可撤销，输入 yes 确认') -cne 'yes') { Write-Host '已取消。'; exit 0 }
$binDir = Join-Path $runtimeDir 'bin'
$previous = [Environment]::GetEnvironmentVariable('Path', 'User')
if ($null -ne $previous) {
    $remaining = @($previous.Split(';') | Where-Object {
        [Environment]::ExpandEnvironmentVariables($_).Trim('"').TrimEnd('\') -ine $binDir.TrimEnd('\')
    }) -join ';'
    [Environment]::SetEnvironmentVariable('Path', $remaining, 'User')
}
if (-not $keepData -and (Test-Path -LiteralPath $dataDir)) { Remove-Item -LiteralPath $dataDir -Recurse -Force }
if (Test-Path -LiteralPath $runtimeDir) { Remove-Item -LiteralPath $runtimeDir -Recurse -Force }
Write-Host 'SFLS 已卸载。任务作品保留；请重新打开终端。'
